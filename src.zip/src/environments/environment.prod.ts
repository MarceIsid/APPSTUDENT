export const environment = {
  production: true,
  apiUrl:'https://repodata-qsp6.onrender.com/'

};
